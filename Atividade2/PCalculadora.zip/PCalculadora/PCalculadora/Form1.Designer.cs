﻿
namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtNum3 = new System.Windows.Forms.TextBox();
            this.Btn_Limpar = new System.Windows.Forms.Button();
            this.Btn_Sair = new System.Windows.Forms.Button();
            this.Btn_Soma = new System.Windows.Forms.Button();
            this.Btn_Sub = new System.Windows.Forms.Button();
            this.Btn_Mult = new System.Windows.Forms.Button();
            this.Btn_Div = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SpringGreen;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(115, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Número 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SpringGreen;
            this.label2.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(115, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Número 2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.SpringGreen;
            this.label3.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(115, 233);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Resultado";
            // 
            // txtNum1
            // 
            this.txtNum1.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum1.Location = new System.Drawing.Point(279, 83);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.Size = new System.Drawing.Size(163, 41);
            this.txtNum1.TabIndex = 3;
            this.txtNum1.Validated += new System.EventHandler(this.txtNum1_Validated);
            // 
            // txtNum2
            // 
            this.txtNum2.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum2.Location = new System.Drawing.Point(279, 152);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.Size = new System.Drawing.Size(163, 41);
            this.txtNum2.TabIndex = 4;
            this.txtNum2.Validated += new System.EventHandler(this.txtNum2_Validated);
            // 
            // txtNum3
            // 
            this.txtNum3.Enabled = false;
            this.txtNum3.Font = new System.Drawing.Font("Lucida Sans Unicode", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNum3.Location = new System.Drawing.Point(279, 233);
            this.txtNum3.Name = "txtNum3";
            this.txtNum3.Size = new System.Drawing.Size(163, 41);
            this.txtNum3.TabIndex = 5;
            // 
            // Btn_Limpar
            // 
            this.Btn_Limpar.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Btn_Limpar.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Limpar.Location = new System.Drawing.Point(588, 92);
            this.Btn_Limpar.Name = "Btn_Limpar";
            this.Btn_Limpar.Size = new System.Drawing.Size(144, 45);
            this.Btn_Limpar.TabIndex = 6;
            this.Btn_Limpar.Text = "LIMPAR";
            this.Btn_Limpar.UseVisualStyleBackColor = false;
            this.Btn_Limpar.Click += new System.EventHandler(this.Btn_Limpar_Click);
            // 
            // Btn_Sair
            // 
            this.Btn_Sair.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Btn_Sair.Font = new System.Drawing.Font("Lucida Sans Unicode", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Sair.Location = new System.Drawing.Point(588, 205);
            this.Btn_Sair.Name = "Btn_Sair";
            this.Btn_Sair.Size = new System.Drawing.Size(144, 45);
            this.Btn_Sair.TabIndex = 7;
            this.Btn_Sair.Text = "SAIR";
            this.Btn_Sair.UseVisualStyleBackColor = false;
            this.Btn_Sair.Click += new System.EventHandler(this.Btn_Sair_Click);
            // 
            // Btn_Soma
            // 
            this.Btn_Soma.BackColor = System.Drawing.Color.Lavender;
            this.Btn_Soma.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Soma.Location = new System.Drawing.Point(104, 336);
            this.Btn_Soma.Name = "Btn_Soma";
            this.Btn_Soma.Size = new System.Drawing.Size(141, 64);
            this.Btn_Soma.TabIndex = 8;
            this.Btn_Soma.Text = "+";
            this.Btn_Soma.UseVisualStyleBackColor = false;
            this.Btn_Soma.Click += new System.EventHandler(this.Btn_Soma_Click);
            // 
            // Btn_Sub
            // 
            this.Btn_Sub.BackColor = System.Drawing.Color.Lavender;
            this.Btn_Sub.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Sub.Location = new System.Drawing.Point(261, 337);
            this.Btn_Sub.Name = "Btn_Sub";
            this.Btn_Sub.Size = new System.Drawing.Size(141, 64);
            this.Btn_Sub.TabIndex = 9;
            this.Btn_Sub.Text = "-";
            this.Btn_Sub.UseVisualStyleBackColor = false;
            this.Btn_Sub.Click += new System.EventHandler(this.Btn_Sub_Click);
            // 
            // Btn_Mult
            // 
            this.Btn_Mult.BackColor = System.Drawing.Color.Lavender;
            this.Btn_Mult.Font = new System.Drawing.Font("Arial", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Mult.Location = new System.Drawing.Point(418, 336);
            this.Btn_Mult.Name = "Btn_Mult";
            this.Btn_Mult.Size = new System.Drawing.Size(141, 64);
            this.Btn_Mult.TabIndex = 10;
            this.Btn_Mult.Text = "x";
            this.Btn_Mult.UseVisualStyleBackColor = false;
            this.Btn_Mult.Click += new System.EventHandler(this.Btn_Mult_Click);
            // 
            // Btn_Div
            // 
            this.Btn_Div.BackColor = System.Drawing.Color.Lavender;
            this.Btn_Div.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Div.Location = new System.Drawing.Point(579, 336);
            this.Btn_Div.Name = "Btn_Div";
            this.Btn_Div.Size = new System.Drawing.Size(141, 64);
            this.Btn_Div.TabIndex = 11;
            this.Btn_Div.Text = "/";
            this.Btn_Div.UseVisualStyleBackColor = false;
            this.Btn_Div.Click += new System.EventHandler(this.Btn_Div_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btn_Div);
            this.Controls.Add(this.Btn_Mult);
            this.Controls.Add(this.Btn_Sub);
            this.Controls.Add(this.Btn_Soma);
            this.Controls.Add(this.Btn_Sair);
            this.Controls.Add(this.Btn_Limpar);
            this.Controls.Add(this.txtNum3);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Calculadora Simples";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtNum3;
        private System.Windows.Forms.Button Btn_Limpar;
        private System.Windows.Forms.Button Btn_Sair;
        private System.Windows.Forms.Button Btn_Soma;
        private System.Windows.Forms.Button Btn_Sub;
        private System.Windows.Forms.Button Btn_Mult;
        private System.Windows.Forms.Button Btn_Div;
    }
}

