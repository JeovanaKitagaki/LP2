﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salário
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cbxNumeroFilhos.SelectedIndex = 0;
        }

        private void btnVerifica_Click(object sender, EventArgs e)
        {
            double descontoINSS = 0;
            double descontoIR = 0;
            double salarioFamilia = 0;
            double salarioLiquido = 0;
            double salarioBruto = 0;

            if((textNome.Text == "") || (textNome.Text.Length <= 0))
                MessageBox.Show("Nome inválido!");
            else if (double.TryParse(mskbxSalarioBruto.Text.Replace("R$", "").Trim(), out salarioBruto))
            {
                if (salarioBruto <= 0)
                    MessageBox.Show("Salário Bruto inválido!");
                else
                {
                    if (salarioBruto <= 800.47)
                    {
                        txtAliquotaINSS.Text = "7.65%";
                        descontoINSS = 0.0765 * salarioBruto;
                    }
                    else if (salarioBruto <= 1050)
                    {
                        txtAliquotaINSS.Text = "8.65%";
                        descontoINSS = 0.0865 * salarioBruto;
                    }
                    else if (salarioBruto <= 1400.77)
                    {
                        txtAliquotaINSS.Text = "9%";
                        descontoINSS = 0.09 * salarioBruto;
                    }
                    else if (salarioBruto <= 2801.56)
                    {
                        txtAliquotaINSS.Text = "11%";
                        descontoINSS = 0.11 * salarioBruto;
                    }
                    else
                    {
                        txtAliquotaINSS.Text = "11%";
                        descontoINSS = 308.17;
                    }

                    txtDescontoINSS.Text = descontoINSS.ToString("N2");

                    if (salarioBruto <= 1257.12)
                    {
                        txtAliquotaIR.Text = "isento";
                        descontoIR = 0;
                    }
                    else if (salarioBruto <= 2512.08)
                    {
                        txtAliquotaIR.Text = "15%";
                        descontoIR = 0.15 * salarioBruto;
                    }
                    else
                    {
                        txtAliquotaIR.Text = "27.5%";
                        descontoIR = 0.275 * salarioBruto;
                    }


                    txtDescontoIR.Text = descontoIR.ToString("N2");

                    if (salarioBruto <= 432.52)
                    {
                        salarioFamilia = 22.33 * Convert.ToDouble(cbxNumeroFilhos.SelectedItem);
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }
                    else if (salarioBruto <= 654.61)
                    {
                        salarioFamilia = 15.74 * Convert.ToDouble(cbxNumeroFilhos.SelectedItem);
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }
                    else
                    {
                        salarioFamilia = 0;
                        txtSalarioFamilia.Text = salarioFamilia.ToString("N2");
                    }

                    salarioLiquido = salarioBruto - descontoINSS - descontoIR + salarioFamilia;

                    txtSalarioLiquido.Text = salarioLiquido.ToString("N2");

                    //messagem label
                    lblMensagem.Visible = true;
                    lblMensagem.Text = "Os descontos do salário ";

                    if (rbtnFeminino.Checked)
                        lblMensagem.Text = lblMensagem.Text + "da Sra " + textNome.Text;
                    else
                        lblMensagem.Text = lblMensagem.Text + "do Sr " + textNome.Text;

                    lblMensagem.Text = lblMensagem.Text + " que é ";

                    if (ckbxSolteiro.Checked)
                        lblMensagem.Text = lblMensagem.Text + " solteiro(a) ";
                    else 
                        lblMensagem.Text = lblMensagem.Text + " casado(a) ";

                    lblMensagem.Text = lblMensagem.Text + " e que tem " +
                        cbxNumeroFilhos.SelectedItem.ToString() + " filho(s) são: ";
                }
            }
        }


        private void textNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar))
            {
                MessageBox.Show("Só aceita letras!");
                e.KeyChar = '\0';
            }
        }

        private void caixa_Enter(object sender, EventArgs e)
        {

        }
    }
}
