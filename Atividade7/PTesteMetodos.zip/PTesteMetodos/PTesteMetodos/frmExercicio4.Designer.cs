﻿
namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtxTexto = new System.Windows.Forms.RichTextBox();
            this.btnMostrar1 = new System.Windows.Forms.Button();
            this.btnLocalize = new System.Windows.Forms.Button();
            this.btnMostrar2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtxTexto
            // 
            this.rtxTexto.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtxTexto.Location = new System.Drawing.Point(142, 63);
            this.rtxTexto.Name = "rtxTexto";
            this.rtxTexto.Size = new System.Drawing.Size(503, 167);
            this.rtxTexto.TabIndex = 0;
            this.rtxTexto.Text = "";
            // 
            // btnMostrar1
            // 
            this.btnMostrar1.BackColor = System.Drawing.Color.Turquoise;
            this.btnMostrar1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrar1.ForeColor = System.Drawing.Color.Green;
            this.btnMostrar1.Location = new System.Drawing.Point(154, 279);
            this.btnMostrar1.Name = "btnMostrar1";
            this.btnMostrar1.Size = new System.Drawing.Size(144, 69);
            this.btnMostrar1.TabIndex = 1;
            this.btnMostrar1.Text = "Caracteres númericos";
            this.btnMostrar1.UseVisualStyleBackColor = false;
            this.btnMostrar1.Click += new System.EventHandler(this.btnMostrar1_Click);
            // 
            // btnLocalize
            // 
            this.btnLocalize.BackColor = System.Drawing.Color.Turquoise;
            this.btnLocalize.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLocalize.ForeColor = System.Drawing.Color.Green;
            this.btnLocalize.Location = new System.Drawing.Point(318, 279);
            this.btnLocalize.Name = "btnLocalize";
            this.btnLocalize.Size = new System.Drawing.Size(144, 69);
            this.btnLocalize.TabIndex = 2;
            this.btnLocalize.Text = "Localize o 1º Caracter";
            this.btnLocalize.UseVisualStyleBackColor = false;
            this.btnLocalize.Click += new System.EventHandler(this.btnLocalize_Click);
            // 
            // btnMostrar2
            // 
            this.btnMostrar2.BackColor = System.Drawing.Color.Turquoise;
            this.btnMostrar2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrar2.ForeColor = System.Drawing.Color.Green;
            this.btnMostrar2.Location = new System.Drawing.Point(484, 279);
            this.btnMostrar2.Name = "btnMostrar2";
            this.btnMostrar2.Size = new System.Drawing.Size(144, 69);
            this.btnMostrar2.TabIndex = 3;
            this.btnMostrar2.Text = "Caracteres Alfabéticos";
            this.btnMostrar2.UseVisualStyleBackColor = false;
            this.btnMostrar2.Click += new System.EventHandler(this.btnMostrar2_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkCyan;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMostrar2);
            this.Controls.Add(this.btnLocalize);
            this.Controls.Add(this.btnMostrar1);
            this.Controls.Add(this.rtxTexto);
            this.Name = "frmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtxTexto;
        private System.Windows.Forms.Button btnMostrar1;
        private System.Windows.Forms.Button btnLocalize;
        private System.Windows.Forms.Button btnMostrar2;
    }
}