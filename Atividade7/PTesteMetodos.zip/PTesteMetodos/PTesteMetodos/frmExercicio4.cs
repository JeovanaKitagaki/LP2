﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnLocalize_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char c in rtxTexto.Text)
                if (char.IsWhiteSpace(c))
                    break;
                else
                    cont++;

            MessageBox.Show("O primeiro caractere branco esta na posicao" + cont);
        }

        private void btnMostrar1_Click(object sender, EventArgs e)
        {
            int contador = 0;
            for (var i = 0; i < rtxTexto.Text.Length; i++)
            {
                if (char.IsNumber(rtxTexto.Text[i]))
                    contador += 1;
            }

            MessageBox.Show("A quantidade de números é: " + contador);
        }

        private void btnMostrar2_Click(object sender, EventArgs e)
        {
            int cont = 0;
            foreach (char c in rtxTexto.Text)
            {
                if (char.IsLetter(c))
                    cont++;
            }
            MessageBox.Show("A quantidade de letras alfabéticas é: " + cont);
        }
    }
}
