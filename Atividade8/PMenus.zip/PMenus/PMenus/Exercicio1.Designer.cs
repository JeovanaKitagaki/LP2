﻿namespace Menu
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchFrase = new System.Windows.Forms.RichTextBox();
            this.btnWhiteSpace = new System.Windows.Forms.Button();
            this.btnQtdeR = new System.Windows.Forms.Button();
            this.btnParLetras = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchFrase
            // 
            this.rchFrase.Location = new System.Drawing.Point(34, 66);
            this.rchFrase.Margin = new System.Windows.Forms.Padding(4);
            this.rchFrase.MaxLength = 100;
            this.rchFrase.Name = "rchFrase";
            this.rchFrase.Size = new System.Drawing.Size(595, 115);
            this.rchFrase.TabIndex = 0;
            this.rchFrase.Text = "";
            // 
            // btnWhiteSpace
            // 
            this.btnWhiteSpace.BackColor = System.Drawing.SystemColors.Info;
            this.btnWhiteSpace.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWhiteSpace.Location = new System.Drawing.Point(124, 189);
            this.btnWhiteSpace.Margin = new System.Windows.Forms.Padding(4);
            this.btnWhiteSpace.Name = "btnWhiteSpace";
            this.btnWhiteSpace.Size = new System.Drawing.Size(405, 42);
            this.btnWhiteSpace.TabIndex = 1;
            this.btnWhiteSpace.Text = "Contar espaços em branco";
            this.btnWhiteSpace.UseVisualStyleBackColor = false;
            this.btnWhiteSpace.Click += new System.EventHandler(this.btnWhiteSpace_Click);
            // 
            // btnQtdeR
            // 
            this.btnQtdeR.BackColor = System.Drawing.SystemColors.Info;
            this.btnQtdeR.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQtdeR.Location = new System.Drawing.Point(124, 239);
            this.btnQtdeR.Margin = new System.Windows.Forms.Padding(4);
            this.btnQtdeR.Name = "btnQtdeR";
            this.btnQtdeR.Size = new System.Drawing.Size(405, 42);
            this.btnQtdeR.TabIndex = 2;
            this.btnQtdeR.Text = "Contar letras \'R\'";
            this.btnQtdeR.UseVisualStyleBackColor = false;
            this.btnQtdeR.Click += new System.EventHandler(this.btnQtdeR_Click);
            // 
            // btnParLetras
            // 
            this.btnParLetras.BackColor = System.Drawing.SystemColors.Info;
            this.btnParLetras.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnParLetras.Location = new System.Drawing.Point(124, 287);
            this.btnParLetras.Margin = new System.Windows.Forms.Padding(4);
            this.btnParLetras.Name = "btnParLetras";
            this.btnParLetras.Size = new System.Drawing.Size(405, 43);
            this.btnParLetras.TabIndex = 3;
            this.btnParLetras.Text = "Contar pares de letras";
            this.btnParLetras.UseVisualStyleBackColor = false;
            this.btnParLetras.Click += new System.EventHandler(this.btnParLetras_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.BackColor = System.Drawing.SystemColors.Info;
            this.btnLimpar.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(124, 338);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(4);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(405, 41);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = false;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfo.Location = new System.Drawing.Point(29, 21);
            this.lblInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(252, 28);
            this.lblInfo.TabIndex = 5;
            this.lblInfo.Text = "Digite a frase que deseja:";
            this.lblInfo.Click += new System.EventHandler(this.lblInfo_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(673, 392);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnParLetras);
            this.Controls.Add(this.btnQtdeR);
            this.Controls.Add(this.btnWhiteSpace);
            this.Controls.Add(this.rchFrase);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio1";
            this.Text = "RichText";
            this.Load += new System.EventHandler(this.frmExercicio1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchFrase;
        private System.Windows.Forms.Button btnWhiteSpace;
        private System.Windows.Forms.Button btnQtdeR;
        private System.Windows.Forms.Button btnParLetras;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Label lblInfo;
    }
}