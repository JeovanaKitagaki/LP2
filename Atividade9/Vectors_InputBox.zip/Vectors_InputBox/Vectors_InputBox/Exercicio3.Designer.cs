﻿namespace InputBox_e_Vetores
{
    partial class frmExercicio7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnExecutar = new System.Windows.Forms.Button();
            this.lbxSaida = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnExecutar
            // 
            this.btnExecutar.BackColor = System.Drawing.Color.Purple;
            this.btnExecutar.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExecutar.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExecutar.Location = new System.Drawing.Point(13, 141);
            this.btnExecutar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExecutar.Name = "btnExecutar";
            this.btnExecutar.Size = new System.Drawing.Size(268, 85);
            this.btnExecutar.TabIndex = 0;
            this.btnExecutar.Text = "EXECUTAR";
            this.btnExecutar.UseVisualStyleBackColor = false;
            this.btnExecutar.Click += new System.EventHandler(this.btnInserir_Click);
            // 
            // lbxSaida
            // 
            this.lbxSaida.FormattingEnabled = true;
            this.lbxSaida.ItemHeight = 16;
            this.lbxSaida.Location = new System.Drawing.Point(324, 60);
            this.lbxSaida.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lbxSaida.Name = "lbxSaida";
            this.lbxSaida.Size = new System.Drawing.Size(433, 260);
            this.lbxSaida.TabIndex = 1;
            this.lbxSaida.SelectedIndexChanged += new System.EventHandler(this.lbxSaida_SelectedIndexChanged);
            // 
            // frmExercicio7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Thistle;
            this.ClientSize = new System.Drawing.Size(803, 383);
            this.Controls.Add(this.lbxSaida);
            this.Controls.Add(this.btnExecutar);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio7";
            this.Text = "Exercicio 7";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnExecutar;
        private System.Windows.Forms.ListBox lbxSaida;
    }
}