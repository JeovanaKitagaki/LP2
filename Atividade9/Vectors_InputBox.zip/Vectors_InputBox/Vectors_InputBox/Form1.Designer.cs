﻿namespace InputBox_e_Vetores
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnListarJuntar = new System.Windows.Forms.Button();
            this.btnInserirAlunos = new System.Windows.Forms.Button();
            this.btnTotalAlunos = new System.Windows.Forms.Button();
            this.btnCalcularMedia = new System.Windows.Forms.Button();
            this.btnExercicio7 = new System.Windows.Forms.Button();
            this.btnFaturamento = new System.Windows.Forms.Button();
            this.btnListarJuntarReverse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnListarJuntar
            // 
            this.btnListarJuntar.BackColor = System.Drawing.Color.Beige;
            this.btnListarJuntar.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListarJuntar.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnListarJuntar.Location = new System.Drawing.Point(63, 26);
            this.btnListarJuntar.Margin = new System.Windows.Forms.Padding(6);
            this.btnListarJuntar.Name = "btnListarJuntar";
            this.btnListarJuntar.Size = new System.Drawing.Size(183, 51);
            this.btnListarJuntar.TabIndex = 0;
            this.btnListarJuntar.Text = "Exercício 1";
            this.btnListarJuntar.UseVisualStyleBackColor = false;
            this.btnListarJuntar.Click += new System.EventHandler(this.btnListarJuntar_Click);
            // 
            // btnInserirAlunos
            // 
            this.btnInserirAlunos.BackColor = System.Drawing.Color.Beige;
            this.btnInserirAlunos.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInserirAlunos.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnInserirAlunos.Location = new System.Drawing.Point(377, 103);
            this.btnInserirAlunos.Margin = new System.Windows.Forms.Padding(6);
            this.btnInserirAlunos.Name = "btnInserirAlunos";
            this.btnInserirAlunos.Size = new System.Drawing.Size(183, 53);
            this.btnInserirAlunos.TabIndex = 1;
            this.btnInserirAlunos.Text = "Exercício 5";
            this.btnInserirAlunos.UseVisualStyleBackColor = false;
            this.btnInserirAlunos.Click += new System.EventHandler(this.btnInserirAlunos_Click);
            // 
            // btnTotalAlunos
            // 
            this.btnTotalAlunos.BackColor = System.Drawing.Color.Beige;
            this.btnTotalAlunos.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTotalAlunos.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnTotalAlunos.Location = new System.Drawing.Point(377, 26);
            this.btnTotalAlunos.Margin = new System.Windows.Forms.Padding(6);
            this.btnTotalAlunos.Name = "btnTotalAlunos";
            this.btnTotalAlunos.Size = new System.Drawing.Size(183, 51);
            this.btnTotalAlunos.TabIndex = 2;
            this.btnTotalAlunos.Text = "Exercício 4 ";
            this.btnTotalAlunos.UseVisualStyleBackColor = false;
            this.btnTotalAlunos.Click += new System.EventHandler(this.btnTotalAlunos_Click);
            // 
            // btnCalcularMedia
            // 
            this.btnCalcularMedia.BackColor = System.Drawing.Color.Beige;
            this.btnCalcularMedia.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularMedia.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnCalcularMedia.Location = new System.Drawing.Point(377, 185);
            this.btnCalcularMedia.Margin = new System.Windows.Forms.Padding(6);
            this.btnCalcularMedia.Name = "btnCalcularMedia";
            this.btnCalcularMedia.Size = new System.Drawing.Size(183, 53);
            this.btnCalcularMedia.TabIndex = 3;
            this.btnCalcularMedia.Text = "Exercício 6";
            this.btnCalcularMedia.UseVisualStyleBackColor = false;
            this.btnCalcularMedia.Click += new System.EventHandler(this.btnCalcularMedia_Click);
            // 
            // btnExercicio7
            // 
            this.btnExercicio7.BackColor = System.Drawing.Color.Beige;
            this.btnExercicio7.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExercicio7.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnExercicio7.Location = new System.Drawing.Point(225, 269);
            this.btnExercicio7.Margin = new System.Windows.Forms.Padding(6);
            this.btnExercicio7.Name = "btnExercicio7";
            this.btnExercicio7.Size = new System.Drawing.Size(183, 53);
            this.btnExercicio7.TabIndex = 4;
            this.btnExercicio7.Text = "Exercício 7";
            this.btnExercicio7.UseVisualStyleBackColor = false;
            this.btnExercicio7.Click += new System.EventHandler(this.btnExercicio7_Click);
            // 
            // btnFaturamento
            // 
            this.btnFaturamento.BackColor = System.Drawing.Color.Beige;
            this.btnFaturamento.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFaturamento.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnFaturamento.Location = new System.Drawing.Point(63, 185);
            this.btnFaturamento.Margin = new System.Windows.Forms.Padding(6);
            this.btnFaturamento.Name = "btnFaturamento";
            this.btnFaturamento.Size = new System.Drawing.Size(183, 53);
            this.btnFaturamento.TabIndex = 5;
            this.btnFaturamento.Text = "Exercício 3";
            this.btnFaturamento.UseVisualStyleBackColor = false;
            this.btnFaturamento.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btnListarJuntarReverse
            // 
            this.btnListarJuntarReverse.BackColor = System.Drawing.Color.Beige;
            this.btnListarJuntarReverse.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListarJuntarReverse.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.btnListarJuntarReverse.Location = new System.Drawing.Point(63, 103);
            this.btnListarJuntarReverse.Margin = new System.Windows.Forms.Padding(6);
            this.btnListarJuntarReverse.Name = "btnListarJuntarReverse";
            this.btnListarJuntarReverse.Size = new System.Drawing.Size(183, 53);
            this.btnListarJuntarReverse.TabIndex = 6;
            this.btnListarJuntarReverse.Text = "Exercício 2";
            this.btnListarJuntarReverse.UseVisualStyleBackColor = false;
            this.btnListarJuntarReverse.Click += new System.EventHandler(this.btnListarJuntarReverse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::InputBox_e_Vetores.Properties.Resources.fundo_tropical_com_espaco_em_branco_52683_36521;
            this.ClientSize = new System.Drawing.Size(663, 360);
            this.Controls.Add(this.btnListarJuntarReverse);
            this.Controls.Add(this.btnFaturamento);
            this.Controls.Add(this.btnExercicio7);
            this.Controls.Add(this.btnCalcularMedia);
            this.Controls.Add(this.btnTotalAlunos);
            this.Controls.Add(this.btnInserirAlunos);
            this.Controls.Add(this.btnListarJuntar);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "Form1";
            this.Text = "Atividade 9";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnListarJuntar;
        private System.Windows.Forms.Button btnInserirAlunos;
        private System.Windows.Forms.Button btnTotalAlunos;
        private System.Windows.Forms.Button btnCalcularMedia;
        private System.Windows.Forms.Button btnExercicio7;
        private System.Windows.Forms.Button btnFaturamento;
        private System.Windows.Forms.Button btnListarJuntarReverse;
    }
}

