﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482111022
{
    public partial class sobre : Form
    {
        public sobre()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblNome1_Click(object sender, EventArgs e)
        {

        }

        private void sobre_Load(object sender, EventArgs e)
        {

        }
    }
}
